def handler(event, context): return 'ok'
